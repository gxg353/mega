"""Global ChartIt exception and warning classes."""

class APIInputError(Exception):
    """Some kind of problem when validating the user input."""
    pass 
