django-syntax-colorize by lethain. Source code at 
http://github.com/lethain/django-syntax-colorize