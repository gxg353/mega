# -*- coding:utf-8 -*-
'''
Created on Jul 21, 2014

@author: xchliu

@module:mega_client.__init__
'''
__all__=['sender','utils']
